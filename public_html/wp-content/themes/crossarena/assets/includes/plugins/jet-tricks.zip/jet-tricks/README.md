# JetTricks For Elementor

Enjoy adding animation on the fly without coding skills

# ChangeLog

## [1.1.0](https://github.com/ZemezLab/jet-tricks/releases/tag/1.1.0)

* Added: New Satellite Widget Extension
* Added: New Tooltip Widget Extension
* Added: New Particles Section Extension

## [1.0.1](https://github.com/ZemezLab/jet-tricks/releases/tag/1.0.1)

* Updated: Elementor 2.1.0 compatibility

## [1.0.0](https://github.com/ZemezLab/jet-tricks/releases/tag/1.0.0)

* Init
